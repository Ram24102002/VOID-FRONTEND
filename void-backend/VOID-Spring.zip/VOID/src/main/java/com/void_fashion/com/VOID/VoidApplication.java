package com.void_fashion.com.VOID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoidApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoidApplication.class, args);
	}

}
