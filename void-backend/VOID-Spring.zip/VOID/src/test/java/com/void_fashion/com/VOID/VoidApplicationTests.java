package com.void_fashion.com.VOID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoidApplicationTests {

	@Test
	void contextLoads() {
	}

}
